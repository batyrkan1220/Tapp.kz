/*
 * Вставьте на посадочную страницу продукта (куда ведёт оффер).
 *
 * В Offer18 в настройках оффера (Advertiser URL) добавьте макрос click id, например:
 *     https://your-product.kz/landing?click_id={tid}
 * Скрипт сохраняет click_id на 30 дней. При регистрации/покупке передайте его на ваш
 * сервер вместе с формой и привяжите к пользователю в базе — cookie во встроенных
 * браузерах Threads/Instagram бывают очищены, серверная запись надёжнее.
 */
(function () {
  var KEY = "o18_click_id", DAYS = 30;
  var id = new URLSearchParams(location.search).get("click_id");
  if (id && /^[\w\-.:]{6,128}$/.test(id)) {
    try { localStorage.setItem(KEY, JSON.stringify({ id: id, exp: Date.now() + DAYS * 864e5 })); } catch (e) {}
    document.cookie = KEY + "=" + encodeURIComponent(id) + ";max-age=" + DAYS * 86400 + ";path=/;SameSite=Lax;Secure";
  }
  window.getClickId = function () {
    try {
      var v = JSON.parse(localStorage.getItem(KEY) || "null");
      if (v && v.exp > Date.now()) return v.id;
    } catch (e) {}
    var m = document.cookie.match(new RegExp("(?:^|; )" + KEY + "=([^;]*)"));
    return m ? decodeURIComponent(m[1]) : null;
  };
})();
