"""Пример: как основной продукт сообщает шлюзу о покупке/регистрации (S2S).

Вызывайте из бэкенда в момент, когда конверсия подтверждена. Секрет POSTBACK_SECRET
хранится только на ваших серверах. Повторная отправка той же транзакции безопасна:
шлюз перешлёт её в Offer18 ровно один раз.
"""
import hashlib
import hmac
import json
import os
import time
import urllib.request

GATEWAY = os.environ.get("GATEWAY_URL", "https://go.yourdomain.kz")
SECRET = os.environ["POSTBACK_SECRET"]


def send_conversion(tid: str, txn_id: str, event: str = "", amount: str = "", currency: str = "") -> dict:
    """tid — click id Offer18, сохранённый при заходе пользователя (см. click-capture.js)."""
    ts = str(int(time.time()))
    canonical = "\n".join([tid, event, txn_id, amount, currency, ts])
    sig = hmac.new(SECRET.encode(), canonical.encode(), hashlib.sha256).hexdigest()
    body = json.dumps(
        {"tid": tid, "event": event, "txn_id": txn_id, "amount": amount, "currency": currency, "ts": ts, "sig": sig}
    ).encode()
    req = urllib.request.Request(
        f"{GATEWAY}/api/v1/postback", data=body, headers={"Content-Type": "application/json"}, method="POST"
    )
    with urllib.request.urlopen(req, timeout=15) as resp:
        return json.load(resp)


if __name__ == "__main__":
    print(send_conversion(tid="D-0001-example", txn_id="order-1001", event="purchase", amount="15000", currency="KZT"))
