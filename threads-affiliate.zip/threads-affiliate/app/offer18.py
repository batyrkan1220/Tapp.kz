"""Клиент Offer18 Network API.

Эндпоинты и поля взяты из knowledgebase.offer18.com (Network API):
  POST /api/m/affiliate         создание партнёра (action=create)
  POST /api/m/affiliate_login   проверка логина (body: mail, password)
  POST /api/m/affiliate_password_reset  (body: affiliate-email) — ВОЗВРАЩАЕТ новый пароль
  GET  /api/m/offers            action=list
  GET  /api/m/report            отчёт по кликам и конверсиям
  GET  https://{tracking_domain}/p  глобальный S2S-постбэк (m, tid, event, sale/payout, currency)

Секреты mid/api-key/secret-key передаются в query-строке (так требует Offer18),
поэтому логирование httpx на уровне INFO отключено.
"""
from __future__ import annotations

import logging
from typing import Any

import httpx

from .config import Settings

logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)
log = logging.getLogger("offer18")


class Offer18Error(Exception):
    """kind: invalid_credentials | exists | rejected | unavailable | bad_response"""

    def __init__(self, kind: str, detail: str = ""):
        super().__init__(f"{kind}: {detail}")
        self.kind = kind
        self.detail = detail


class Offer18Client:
    def __init__(self, settings: Settings, http: httpx.AsyncClient | None = None):
        self.s = settings
        self.http = http or httpx.AsyncClient(timeout=httpx.Timeout(15.0, connect=5.0))

    # ------------------------------------------------------------ низкий уровень
    def _auth(self) -> dict[str, str]:
        return {"mid": self.s.mid, "api-key": self.s.api_key, "secret-key": self.s.secret_key}

    async def _call(self, method: str, path: str, params: dict | None = None, form: dict | None = None) -> Any:
        url = f"{self.s.offer18_base}{path}"
        query = {**self._auth(), **(params or {})}
        try:
            resp = await self.http.request(method, url, params=query, data=form)
        except httpx.HTTPError as exc:
            log.warning("Offer18 недоступен: %s", type(exc).__name__)
            raise Offer18Error("unavailable", type(exc).__name__) from exc
        if resp.status_code >= 500:
            raise Offer18Error("unavailable", f"HTTP {resp.status_code}")
        try:
            return resp.json()
        except ValueError as exc:
            raise Offer18Error("bad_response", f"HTTP {resp.status_code}, не JSON") from exc

    @staticmethod
    def _ok(data: Any) -> bool:
        return isinstance(data, dict) and str(data.get("status", data.get("response", ""))) == "200"

    # ------------------------------------------------------------ партнёры
    async def login(self, email: str, password: str) -> str:
        data = await self._call("POST", "/api/m/affiliate_login", form={"mail": email, "password": password})
        if (
            isinstance(data, dict)
            and str(data.get("status")) == "200"
            and data.get("response") == "affiliate_login_validated"
            and data.get("affiliate_id")
        ):
            return str(data["affiliate_id"])
        raise Offer18Error("invalid_credentials")

    async def create_affiliate(self, *, first_name, last_name, email, password, mobile, signup_ip, status) -> str:
        form = {
            "first_name": first_name,
            "last_name": last_name,
            "email": email,
            "password": password,
            "mobile": mobile,
            "signup_ip": signup_ip,
            "status": status,
        }
        data = await self._call("POST", "/api/m/affiliate", params={"action": "create"}, form=form)
        if self._ok(data) and data.get("affiliate_id") not in (None, ""):
            # Ответ Offer18 содержит пароль — наружу его не отдаём и нигде не сохраняем.
            return str(data["affiliate_id"])
        text = str(data).lower()
        if "exist" in text or "already" in text or "duplicate" in text:
            raise Offer18Error("exists")
        raise Offer18Error("rejected")

    async def reset_password(self, email: str) -> tuple[str, str]:
        """Возвращает (affiliate_id, новый_пароль). Пароль можно только отправить на почту партнёра."""
        data = await self._call("POST", "/api/m/affiliate_password_reset", form={"affiliate-email": email})
        if self._ok(data) and data.get("password") and data.get("affiliate_id"):
            return str(data["affiliate_id"]), str(data["password"])
        raise Offer18Error("rejected")

    # ------------------------------------------------------------ каталог и отчёты
    async def list_offers(self) -> dict:
        data = await self._call(
            "GET", "/api/m/offers", params={"action": "list", "status": "1", "limit": str(self.s.offers_limit)}
        )
        if not isinstance(data, dict) or str(data.get("response", data.get("status"))) != "200":
            raise Offer18Error("bad_response", "offers")
        offers = data.get("data") or {}
        if len(offers) >= self.s.offers_limit:
            log.warning("Список офферов упёрся в лимит %s — увеличьте OFFERS_LIMIT", self.s.offers_limit)
        return data

    async def report(self, params: dict) -> list[dict]:
        data = await self._call("GET", "/api/m/report", params=params)
        if not isinstance(data, dict) or str(data.get("status")) != "200":
            raise Offer18Error("bad_response", "report")
        return list(data.get("reports") or [])

    # ------------------------------------------------------------ постбэк
    async def send_postback(self, *, tid: str, event: str, amount: str, currency: str) -> None:
        params = {"m": self.s.mid, "tid": tid}
        if event:
            params["event"] = event
        if amount:
            params[self.s.postback_amount_param] = amount
        if currency:
            params["currency"] = currency
        url = f"https://{self.s.tracking_domain}/p"
        try:
            resp = await self.http.get(url, params=params)
        except httpx.HTTPError as exc:
            raise Offer18Error("unavailable", type(exc).__name__) from exc
        if resp.status_code >= 400:
            raise Offer18Error("unavailable", f"postback HTTP {resp.status_code}")
