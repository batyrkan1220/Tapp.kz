"""Настройки приложения. Все секреты берутся только из переменных окружения."""
from __future__ import annotations

import os
from dataclasses import dataclass, field


def _bool(value: str | None, default: bool = False) -> bool:
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


@dataclass
class Settings:
    # --- Offer18 (никогда не попадают в клиентский код) ---
    mid: str = ""
    api_key: str = ""
    secret_key: str = ""
    offer18_base: str = "https://api.offer18.com"

    # --- Домены ---
    # Трекинговый домен, CNAME на Offer18 (клики и глобальный постбэк /p)
    tracking_domain: str = ""
    # Публичный адрес шлюза (короткие ссылки /t/..., сам дашборд)
    public_base_url: str = "http://localhost:8000"

    # --- Безопасность ---
    jwt_secret: str = ""
    jwt_ttl_hours: int = 12
    postback_secret: str = ""
    postback_max_skew_seconds: int = 600
    trust_proxy: bool = False

    # --- Поведение ---
    signup_status: str = "Pending"  # Pending | Approved
    report_tz: str = "Asia/Almaty"
    offers_ttl: int = 300
    offers_limit: int = 500
    reports_ttl: int = 60
    postback_amount_param: str = "sale"  # sale (CPS) или payout (revshare)
    default_og_image: str = ""

    # --- Почта (для сброса пароля) ---
    smtp_host: str = ""
    smtp_port: int = 587
    smtp_user: str = ""
    smtp_password: str = ""
    smtp_from: str = ""

    # --- Прочее ---
    db_path: str = "data/app.db"
    dev_mode: bool = False
    extra: dict = field(default_factory=dict)

    @classmethod
    def from_env(cls) -> "Settings":
        e = os.environ.get
        return cls(
            mid=e("OFFER18_MID", ""),
            api_key=e("OFFER18_API_KEY", ""),
            secret_key=e("OFFER18_SECRET_KEY", ""),
            offer18_base=e("OFFER18_BASE_URL", "https://api.offer18.com").rstrip("/"),
            tracking_domain=e("TRACKING_DOMAIN", "").strip().removeprefix("https://").rstrip("/"),
            public_base_url=e("PUBLIC_BASE_URL", "http://localhost:8000").rstrip("/"),
            jwt_secret=e("JWT_SECRET", ""),
            jwt_ttl_hours=int(e("JWT_TTL_HOURS", "12")),
            postback_secret=e("POSTBACK_SECRET", ""),
            postback_max_skew_seconds=int(e("POSTBACK_MAX_SKEW_SECONDS", "600")),
            trust_proxy=_bool(e("TRUST_PROXY")),
            signup_status=e("AFFILIATE_SIGNUP_STATUS", "Pending"),
            report_tz=e("REPORT_TZ", "Asia/Almaty"),
            offers_ttl=int(e("OFFERS_CACHE_TTL", "300")),
            offers_limit=int(e("OFFERS_LIMIT", "500")),
            reports_ttl=int(e("REPORTS_CACHE_TTL", "60")),
            postback_amount_param=e("POSTBACK_AMOUNT_PARAM", "sale"),
            default_og_image=e("DEFAULT_OG_IMAGE", ""),
            smtp_host=e("SMTP_HOST", ""),
            smtp_port=int(e("SMTP_PORT", "587")),
            smtp_user=e("SMTP_USER", ""),
            smtp_password=e("SMTP_PASSWORD", ""),
            smtp_from=e("SMTP_FROM", ""),
            db_path=e("DB_PATH", "data/app.db"),
            dev_mode=_bool(e("DEV_MODE")),
        )

    def validate(self) -> None:
        """В боевом режиме приложение не стартует с пустыми или слабыми секретами."""
        if self.dev_mode:
            return
        problems = []
        for attr, env_name in (
            ("mid", "OFFER18_MID"), ("api_key", "OFFER18_API_KEY"),
            ("secret_key", "OFFER18_SECRET_KEY"), ("tracking_domain", "TRACKING_DOMAIN"),
        ):
            if not getattr(self, attr):
                problems.append(env_name)
        if len(self.jwt_secret) < 32:
            problems.append("JWT_SECRET (не короче 32 символов)")
        if len(self.postback_secret) < 32:
            problems.append("POSTBACK_SECRET (не короче 32 символов)")
        if self.signup_status not in {"Pending", "Approved"}:
            problems.append("AFFILIATE_SIGNUP_STATUS (Pending или Approved)")
        if problems:
            raise RuntimeError("Не заданы или неверны настройки: " + ", ".join(problems))
