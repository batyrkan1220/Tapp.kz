(() => {
  "use strict";

  // ---------- строки интерфейса (русский; для казахского добавьте второй словарь) ----------
  const PLACEMENTS = {
    bio: "Био профиля",
    post: "Новый пост",
    comment: "Комментарий",
    reply: "Ответ в треде",
  };
  const RANGES = { today: "Сегодня", yesterday: "Вчера", "7d": "7 дней", month: "Этот месяц" };

  // ---------- утилиты ----------
  const root = document.getElementById("app");
  const toastEl = document.getElementById("toast");
  const nf = new Intl.NumberFormat("ru-RU", { maximumFractionDigits: 2 });
  const store = {
    get() { try { return localStorage.getItem("token"); } catch { return null; } },
    set(v) { try { v ? localStorage.setItem("token", v) : localStorage.removeItem("token"); } catch { /* приватный режим */ } },
  };
  let token = store.get();
  let me = null;

  function h(tag, props, ...kids) {
    const el = document.createElement(tag);
    // Кнопка без явного типа внутри формы по умолчанию отправляет её — этого не хотим.
    if (tag === "button" && !(props && props.type)) el.type = "button";
    for (const [k, v] of Object.entries(props || {})) {
      if (v === false || v == null) continue;
      if (k === "class") el.className = v;
      else if (k.startsWith("on")) el.addEventListener(k.slice(2), v);
      else if (k === "text") el.textContent = v;
      else el.setAttribute(k, v === true ? "" : v);
    }
    for (const kid of kids.flat()) {
      if (kid == null || kid === false) continue;
      el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
    }
    return el;
  }

  let toastTimer;
  function toast(text) {
    toastEl.textContent = text;
    toastEl.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove("show"), 2200);
  }

  async function copy(text) {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const t = h("textarea", { style: "position:fixed;opacity:0" });
      t.value = text;
      document.body.append(t);
      t.select();
      document.execCommand("copy");
      t.remove();
    }
    toast("Скопировано");
  }

  async function api(path, { method = "GET", body, blob = false } = {}) {
    let res;
    try {
      res = await fetch("/api/v1" + path, {
        method,
        headers: {
          ...(body ? { "Content-Type": "application/json" } : {}),
          ...(token ? { Authorization: "Bearer " + token } : {}),
        },
        body: body ? JSON.stringify(body) : undefined,
      });
    } catch {
      throw new Error("Нет соединения. Проверьте интернет и повторите.");
    }
    if (res.status === 401 && token && !path.startsWith("/auth/")) {
      logout();
      throw new Error("Сессия истекла. Войдите снова.");
    }
    if (blob && res.ok) return res.blob();
    let data = null;
    try { data = await res.json(); } catch { /* не JSON */ }
    if (!res.ok || !data || data.success === false) {
      throw new Error((data && data.error) || "Что-то пошло не так. Повторите попытку.");
    }
    return data;
  }

  const money = (v, cur) => `${nf.format(v)} ${cur || ""}`.trim();
  const icon = (d) => {
    const s = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    s.setAttribute("viewBox", "0 0 24 24");
    s.setAttribute("fill", "none");
    s.setAttribute("stroke", "currentColor");
    s.setAttribute("stroke-width", "2");
    s.setAttribute("stroke-linecap", "round");
    s.setAttribute("stroke-linejoin", "round");
    const p = document.createElementNS("http://www.w3.org/2000/svg", "path");
    p.setAttribute("d", d);
    s.append(p);
    return s;
  };

  function logout() {
    token = null;
    me = null;
    store.set(null);
    location.hash = "#/login";
  }

  function busy(btn, on, label) {
    btn.disabled = on;
    if (label) btn.textContent = on ? "Подождите…" : label;
  }

  // ---------- экраны входа ----------
  function authShell(active, content) {
    return h("div", { class: "wrap" },
      h("div", { class: "hero" },
        h("div", { class: "brand", text: "Партнёрский кабинет" }),
        h("h1", { text: "Зарабатывайте на трафике из Threads" }),
        h("p", { class: "muted", text: "Берите офферы, делайте ссылки под каждый пост и следите за доходом в одном месте." })),
      h("div", { class: "tabs2" },
        h("a", { href: "#/login", class: active === "login" ? "on" : "", text: "Вход" }),
        h("a", { href: "#/register", class: active === "register" ? "on" : "", text: "Регистрация" })),
      content);
  }

  function field(label, name, type, opts = {}) {
    const id = "f_" + name;
    return [h("label", { for: id, text: label }),
      h("input", { id, name, type, required: true, autocomplete: opts.ac, inputmode: opts.mode, minlength: opts.min, maxlength: opts.max, placeholder: opts.ph })];
  }

  function formMsg(form) {
    let box = form.querySelector(".msg");
    if (!box) { box = h("div", { class: "msg", hidden: true }); form.prepend(box); }
    return (text, isErr = true) => {
      box.hidden = !text;
      box.className = "msg" + (isErr ? " err" : "");
      box.textContent = text || "";
    };
  }

  function viewLogin() {
    const btn = h("button", { class: "btn block", type: "submit", text: "Войти" });
    const form = h("form", { class: "card", novalidate: false },
      field("Email", "email", "email", { ac: "username", mode: "email" }),
      field("Пароль", "password", "password", { ac: "current-password" }),
      btn,
      h("p", {}, h("a", { href: "#/forgot", class: "link", text: "Забыли пароль?" })));
    const say = formMsg(form);
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      say("");
      busy(btn, true, "Войти");
      try {
        const d = await api("/auth/login", { method: "POST", body: { email: form.email.value.trim(), password: form.password.value } });
        token = d.data.token; store.set(token);
        location.hash = "#/offers";
      } catch (err) { say(err.message); }
      busy(btn, false, "Войти");
    });
    return authShell("login", form);
  }

  function viewRegister() {
    const btn = h("button", { class: "btn block", type: "submit", text: "Создать аккаунт" });
    const form = h("form", { class: "card" },
      field("Имя", "first_name", "text", { ac: "given-name", max: 60 }),
      field("Фамилия", "last_name", "text", { ac: "family-name", max: 60 }),
      field("Телефон / WhatsApp", "phone", "tel", { ac: "tel", mode: "tel", ph: "+7 700 000 00 00" }),
      field("Email", "email", "email", { ac: "email", mode: "email" }),
      field("Пароль (от 8 символов)", "password", "password", { ac: "new-password", min: 8, max: 128 }),
      btn,
      h("p", { class: "muted", text: "Регистрируясь, вы соглашаетесь с условиями партнёрской программы и обработкой персональных данных." }));
    const say = formMsg(form);
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      say("");
      busy(btn, true, "Создать аккаунт");
      try {
        const d = await api("/auth/register", {
          method: "POST",
          body: {
            first_name: form.first_name.value.trim(), last_name: form.last_name.value.trim(),
            phone: form.phone.value.trim(), email: form.email.value.trim(), password: form.password.value,
          },
        });
        if (d.data.token) { token = d.data.token; store.set(token); location.hash = "#/offers"; return; }
        say(d.data.pending_moderation
          ? "Заявка принята и ожидает проверки. Как только её одобрят, войдите с этим email и паролем."
          : "Аккаунт создан. Теперь войдите.", false);
        form.reset();
      } catch (err) { say(err.message); }
      busy(btn, false, "Создать аккаунт");
    });
    return authShell("register", form);
  }

  function viewForgot() {
    const btn = h("button", { class: "btn block", type: "submit", text: "Отправить ссылку" });
    const form = h("form", { class: "card" },
      h("p", { class: "muted", text: "Укажите email — мы пришлём ссылку для получения нового пароля." }),
      field("Email", "email", "email", { ac: "username", mode: "email" }),
      btn,
      h("p", {}, h("a", { href: "#/login", class: "link", text: "Назад ко входу" })));
    const say = formMsg(form);
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      say("");
      busy(btn, true, "Отправить ссылку");
      try {
        const d = await api("/auth/password-reset", { method: "POST", body: { email: form.email.value.trim() } });
        say(d.message, false);
      } catch (err) { say(err.message); }
      busy(btn, false, "Отправить ссылку");
    });
    return authShell("login", form);
  }

  function viewReset(query) {
    const tk = new URLSearchParams(query).get("token") || "";
    const btn = h("button", { class: "btn block", type: "button", text: "Получить новый пароль" });
    const box = h("div", { class: "card" },
      h("p", { text: "Нажмите кнопку — новый пароль придёт на ваш email." }), btn,
      h("p", {}, h("a", { href: "#/login", class: "link", text: "Ко входу" })));
    const say = formMsg(box);
    btn.addEventListener("click", async () => {
      say("");
      busy(btn, true, "Получить новый пароль");
      try {
        const d = await api("/auth/password-reset/confirm", { method: "POST", body: { token: tk } });
        say(d.message, false);
        btn.hidden = true;
      } catch (err) { say(err.message); busy(btn, false, "Получить новый пароль"); }
    });
    return authShell("login", box);
  }

  // ---------- каркас кабинета ----------
  function appShell(active, ...content) {
    const item = (href, key, label, d) =>
      h("a", { href, class: active === key ? "on" : "" }, icon(d), label);
    return h("div", {},
      h("div", { class: "wrap" }, content),
      h("nav", { class: "nav", "aria-label": "Разделы" },
        h("div", { class: "nav-in" },
          item("#/offers", "offers", "Офферы", "M20 7H4a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2zM16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"),
          item("#/links", "links", "Ссылки", "M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"),
          item("#/stats", "stats", "Статистика", "M3 3v18h18M7 15l4-4 3 3 5-6"),
          item("#/profile", "profile", "Профиль", "M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z"))));
  }

  const loading = () => h("div", { class: "spin", text: "Загрузка…" });
  const failure = (err, retry) => h("div", { class: "empty" },
    h("p", { text: err.message }), h("button", { class: "btn small", onclick: retry, text: "Повторить" }));

  // ---------- офферы и генератор ссылок ----------
  function openSheet(...content) {
    const bg = h("div", { class: "sheet-bg", onclick: (e) => { if (e.target === bg) close(); } });
    const close = () => bg.remove();
    bg.append(h("div", { class: "sheet", role: "dialog", "aria-modal": "true" }, content,
      h("button", { class: "btn ghost block", onclick: close, text: "Закрыть" })));
    document.body.append(bg);
    return close;
  }

  function copyBox(value) {
    return h("div", { class: "copybox" },
      h("input", { type: "text", readonly: true, value, onfocus: (e) => e.target.select(), "aria-label": "Ссылка" }),
      h("button", { class: "btn small", onclick: () => copy(value), text: "Копировать" }));
  }

  async function qrImage(code, holder) {
    try {
      const blob = await api(`/links/${encodeURIComponent(code)}/qr.svg`, { blob: true });
      const url = URL.createObjectURL(blob);
      holder.replaceChildren(
        h("img", { class: "qr", src: url, alt: "QR-код ссылки" }),
        h("p", { class: "muted", style: "text-align:center" }, h("a", { href: url, download: `qr-${code}.svg`, class: "link", text: "Скачать QR" })));
    } catch (err) { holder.replaceChildren(h("p", { class: "muted", text: err.message })); }
  }

  function linkResult(link) {
    const qrHolder = h("div");
    qrImage(link.code, qrHolder);
    return h("div", {},
      h("h2", { text: "Ссылка готова" }),
      h("p", { class: "muted", text: "Короткая ссылка — для Threads: у неё красивая карточка предпросмотра." }),
      copyBox(link.short_url),
      qrHolder);
  }

  function offerSheet(offer) {
    const chips = h("div", { class: "chips", role: "radiogroup", "aria-label": "Где разместите ссылку" },
      Object.entries(PLACEMENTS).map(([val, label], i) =>
        h("label", { class: "chip" },
          h("input", { type: "radio", name: "placement", value: val, checked: i === 0 }),
          h("span", { text: label }))));
    const tag = h("input", { type: "text", name: "campaign_tag", maxlength: 32, pattern: "[A-Za-z0-9_\\-]{0,32}", placeholder: "например, oct_promo" });
    const btn = h("button", { class: "btn block", type: "submit", text: "Создать ссылку" });
    const out = h("div");
    const form = h("form", {},
      h("h2", { text: offer.title }),
      h("p", { class: "muted", text: "Где вы разместите ссылку?" }), chips,
      h("label", { for: "ctag", text: "Метка кампании (необязательно, латиница, цифры, - и _)" }),
      Object.assign(tag, { id: "ctag" }), btn, out);
    const say = formMsg(form);
    form.addEventListener("submit", async (e) => {
      e.preventDefault();
      say("");
      busy(btn, true, "Создать ссылку");
      try {
        const d = await api("/links/generate", {
          method: "POST",
          body: { offer_id: offer.offer_id, placement: form.placement.value, campaign_tag: tag.value.trim() },
        });
        out.replaceChildren(linkResult(d.data));
      } catch (err) { say(err.message); }
      busy(btn, false, "Создать ссылку");
    });
    openSheet(form);
  }

  async function viewOffers() {
    const box = h("div", {}, loading());
    const load = async () => {
      box.replaceChildren(loading());
      try {
        const { data } = await api("/offers");
        if (!data.length) {
          box.replaceChildren(h("div", { class: "empty" },
            h("p", { class: "title", text: "Пока нет доступных офферов" }),
            h("p", { text: "Когда вашу заявку одобрят, офферы появятся здесь." })));
          return;
        }
        box.replaceChildren(...data.map((o) => h("article", { class: "card" },
          h("div", { class: "row top" },
            o.logo_url
              ? h("img", { class: "logo", src: o.logo_url, alt: "", loading: "lazy", referrerpolicy: "no-referrer", onerror: (e) => e.target.replaceWith(h("div", { class: "logo ph", text: o.title.slice(0, 1).toUpperCase() })) })
              : h("div", { class: "logo ph", text: o.title.slice(0, 1).toUpperCase() }),
            h("div", { class: "grow" },
              h("div", { class: "title", text: o.title }),
              h("div", {}, h("span", { class: "badge", text: `${money(o.payout, o.currency)} · ${o.model}` }),
                o.countries ? h("span", { class: "muted", text: "  " + o.countries }) : null))),
          o.description ? h("p", { class: "clamp muted", text: o.description }) : null,
          h("button", { class: "btn block", onclick: () => offerSheet(o), text: "Создать ссылку" }))));
      } catch (err) { box.replaceChildren(failure(err, load)); }
    };
    load();
    return appShell("offers", h("h1", { text: "Офферы" }), h("p", { class: "muted", text: "Выберите оффер и создайте ссылку под нужное место в Threads." }), box);
  }

  // ---------- мои ссылки ----------
  async function viewLinks() {
    const box = h("div", {}, loading());
    const load = async () => {
      box.replaceChildren(loading());
      try {
        const { data } = await api("/links");
        if (!data.length) {
          box.replaceChildren(h("div", { class: "empty" }, h("p", { text: "Вы ещё не создавали ссылок." }),
            h("a", { href: "#/offers", class: "btn small", text: "К офферам" })));
          return;
        }
        box.replaceChildren(...data.map((l) => {
          const qr = h("div");
          return h("article", { class: "card" },
            h("div", { class: "title", text: l.title || `Оффер ${l.offer_id}` }),
            h("div", { class: "muted", text: PLACEMENTS[l.placement] + (l.campaign_tag ? ` · ${l.campaign_tag}` : "") }),
            copyBox(l.short_url),
            h("button", { class: "link", onclick: (e) => { e.target.hidden = true; qrImage(l.code, qr); }, text: "Показать QR" }),
            qr);
        }));
      } catch (err) { box.replaceChildren(failure(err, load)); }
    };
    load();
    return appShell("links", h("h1", { text: "Мои ссылки" }), box);
  }

  // ---------- статистика ----------
  let range = "7d";
  async function viewStats() {
    const box = h("div", {}, loading());
    const chips = h("div", { class: "chips", role: "radiogroup", "aria-label": "Период" },
      Object.entries(RANGES).map(([val, label]) =>
        h("label", { class: "chip" },
          h("input", { type: "radio", name: "range", value: val, checked: val === range, onchange: () => { range = val; load(); } }),
          h("span", { text: label }))));

    const kpi = (value, label, wide) => h("div", { class: "kpi" + (wide ? " wide" : "") }, h("b", { text: value }), h("small", { text: label }));

    const table = (heads, rows) => h("table", {},
      h("thead", {}, h("tr", {}, heads.map((t, i) => h("th", { class: i ? "n" : "", text: t })))),
      h("tbody", {}, rows.map((r) => h("tr", {}, r.map((c, i) => h("td", { class: i ? "n" : "", text: c }))))));

    const load = async () => {
      box.replaceChildren(loading());
      try {
        const { data: d } = await api("/stats?range=" + range);
        const cur = Object.entries(d.earnings);
        const parts = [h("div", { class: "kpis" },
          kpi(nf.format(d.totals.clicks), "Переходы"),
          kpi(nf.format(d.totals.conversions), "Конверсии"),
          kpi(d.totals.cr + " %", "Конверсия в клик (CR)"),
          d.totals.impressions ? kpi(nf.format(d.totals.impressions), "Показы") : kpi("—", "Показы не ведутся"))];

        parts.push(h("h2", { text: "Доход" }));
        if (!cur.length) parts.push(h("p", { class: "muted", text: "За выбранный период начислений нет." }));
        for (const [c, v] of cur) {
          parts.push(h("div", { class: "kpis" },
            kpi(money(v.approved, c), "Подтверждено"),
            kpi(money(v.pending, c), "На проверке")));
        }

        if (d.daily.length > 1) {
          const max = Math.max(1, ...d.daily.map((x) => x.clicks));
          parts.push(h("h2", { text: "Переходы по дням" }),
            h("div", { class: "card" }, h("div", { class: "bars", role: "img", "aria-label": "График переходов по дням" },
              d.daily.map((x) => h("div", { class: "bar", title: `${x.date}: ${x.clicks}` },
                h("i", { style: `height:${Math.round((x.clicks / max) * 100)}%` }),
                h("small", { text: x.date.slice(8) + "." + x.date.slice(5, 7) }))))));
        }
        if (d.by_placement.length) {
          parts.push(h("h2", { text: "По местам размещения" }), h("div", { class: "card" },
            table(["Место", "Клики", "Конв."], d.by_placement.map((p) => [PLACEMENTS[p.placement] || p.placement, p.clicks, p.conversions]))));
        }
        if (d.by_offer.length) {
          parts.push(h("h2", { text: "По офферам" }), h("div", { class: "card" },
            table(["Оффер", "Клики", "Конв."], d.by_offer.map((o) => [o.title || o.offer_id, o.clicks, o.conversions]))));
        }
        parts.push(h("p", { class: "muted", text: `Период: ${d.date_from} — ${d.date_end}. Данные обновляются раз в минуту, статус «На проверке» меняется после модерации конверсий.` }));
        box.replaceChildren(...parts);
      } catch (err) { box.replaceChildren(failure(err, load)); }
    };
    load();
    return appShell("stats", h("h1", { text: "Статистика" }), chips, box);
  }

  // ---------- профиль ----------
  async function viewProfile() {
    const box = h("div", {}, loading());
    try {
      if (!me) me = (await api("/me")).data;
      box.replaceChildren(h("div", { class: "card" },
        me.name ? h("div", { class: "title", text: me.name }) : null,
        h("div", { class: "muted", text: me.email }),
        h("div", { class: "muted", text: "ID партнёра: " + me.affiliate_id })),
        h("h2", { text: "Советы для Threads" }),
        h("div", { class: "card" },
          h("p", { text: "Используйте отдельную ссылку для био, постов и комментариев — так в статистике видно, что работает." }),
          h("p", { text: "Вставляйте короткую ссылку: она показывает карточку предпросмотра с названием и картинкой оффера." })),
        h("button", { class: "btn ghost block", onclick: logout, text: "Выйти" }));
    } catch (err) { box.replaceChildren(failure(err, () => route())); }
    return appShell("profile", h("h1", { text: "Профиль" }), box);
  }

  // ---------- маршрутизатор ----------
  const PUBLIC = { login: viewLogin, register: viewRegister, forgot: viewForgot, reset: viewReset };
  const PRIVATE = { offers: viewOffers, links: viewLinks, stats: viewStats, profile: viewProfile };

  async function route() {
    const [, path = "", query = ""] = location.hash.match(/^#\/([^?]*)\??(.*)$/) || [];
    document.querySelectorAll(".sheet-bg").forEach((n) => n.remove());
    let view;
    if (PRIVATE[path]) {
      if (!token) { location.hash = "#/login"; return; }
      view = await PRIVATE[path]();
    } else if (PUBLIC[path]) {
      if (token && (path === "login" || path === "register")) { location.hash = "#/offers"; return; }
      view = PUBLIC[path](query);
    } else {
      location.hash = token ? "#/offers" : "#/login";
      return;
    }
    root.replaceChildren(view);
    window.scrollTo(0, 0);
  }

  window.addEventListener("hashchange", route);
  route();
})();
