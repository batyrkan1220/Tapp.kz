"""JWT, лимитер запросов, подпись постбэка, кэш с TTL."""
from __future__ import annotations

import asyncio
import hashlib
import hmac
import time
from collections import defaultdict, deque
from dataclasses import dataclass
from typing import Awaitable, Callable

import jwt
from fastapi import HTTPException

from .config import Settings


# ---------------------------------------------------------------- JWT
@dataclass
class Partner:
    affiliate_id: str
    email: str


def create_token(settings: Settings, affiliate_id: str, email: str) -> str:
    now = int(time.time())
    payload = {
        "sub": str(affiliate_id),
        "email": email,
        "iat": now,
        "exp": now + settings.jwt_ttl_hours * 3600,
    }
    return jwt.encode(payload, settings.jwt_secret, algorithm="HS256")


def decode_token(settings: Settings, token: str) -> Partner:
    try:
        data = jwt.decode(token, settings.jwt_secret, algorithms=["HS256"], options={"require": ["exp", "sub"]})
    except jwt.PyJWTError:
        raise HTTPException(401, "Сессия истекла. Войдите снова.")
    return Partner(affiliate_id=str(data["sub"]), email=str(data.get("email", "")))


# ---------------------------------------------------------------- лимитер
class RateLimiter:
    """Скользящее окно в памяти процесса. При нескольких воркерах нужен общий Redis."""

    def __init__(self) -> None:
        self._hits: dict[str, deque[float]] = defaultdict(deque)

    def check(self, key: str, limit: int, window: int) -> None:
        now = time.monotonic()
        q = self._hits[key]
        while q and now - q[0] > window:
            q.popleft()
        if len(q) >= limit:
            raise HTTPException(429, "Слишком много попыток. Подождите немного и повторите.")
        q.append(now)


# ---------------------------------------------------------------- постбэк
def postback_signature(secret: str, tid: str, event: str, txn_id: str, amount: str, currency: str, ts: str) -> str:
    """HMAC-SHA256 от канонической строки. Эту же функцию вызывает продукт при отправке."""
    canonical = "\n".join([tid, event, txn_id, amount, currency, ts])
    return hmac.new(secret.encode(), canonical.encode(), hashlib.sha256).hexdigest()


def verify_postback(settings: Settings, tid, event, txn_id, amount, currency, ts, sig) -> None:
    try:
        ts_int = int(ts)
    except (TypeError, ValueError):
        raise HTTPException(400, "Некорректная метка времени.")
    if abs(time.time() - ts_int) > settings.postback_max_skew_seconds:
        raise HTTPException(401, "Запрос устарел.")
    expected = postback_signature(settings.postback_secret, tid, event, txn_id, amount, currency, str(ts))
    if not hmac.compare_digest(expected, str(sig)):
        raise HTTPException(401, "Неверная подпись.")


# ---------------------------------------------------------------- кэш
class TTLCache:
    """Кэш с защитой от «толпы» запросов и выдачей устаревших данных при сбое Offer18."""

    def __init__(self) -> None:
        self._data: dict[str, tuple[float, object]] = {}
        self._locks: dict[str, asyncio.Lock] = defaultdict(asyncio.Lock)

    async def get_or_load(self, key: str, ttl: int, loader: Callable[[], Awaitable[object]]):
        hit = self._data.get(key)
        if hit and hit[0] > time.monotonic():
            return hit[1]
        async with self._locks[key]:
            hit = self._data.get(key)
            if hit and hit[0] > time.monotonic():
                return hit[1]
            try:
                value = await loader()
            except Exception:
                if hit:  # stale-if-error
                    return hit[1]
                raise
            self._data[key] = (time.monotonic() + ttl, value)
            return value

    def clear(self) -> None:
        self._data.clear()
