"""SQLite-хранилище. Пароли партнёров здесь НЕ хранятся: вход проверяет Offer18."""
from __future__ import annotations

import os
import sqlite3
import threading
import time

SCHEMA = """
CREATE TABLE IF NOT EXISTS partners (
    affiliate_id TEXT PRIMARY KEY,
    email        TEXT NOT NULL UNIQUE,
    first_name   TEXT NOT NULL DEFAULT '',
    last_name    TEXT NOT NULL DEFAULT '',
    phone        TEXT NOT NULL DEFAULT '',
    created_at   INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS short_links (
    code         TEXT PRIMARY KEY,
    affiliate_id TEXT NOT NULL,
    offer_id     TEXT NOT NULL,
    placement    TEXT NOT NULL,
    campaign     TEXT NOT NULL DEFAULT '',
    target_url   TEXT NOT NULL,
    og_title     TEXT NOT NULL DEFAULT '',
    og_desc      TEXT NOT NULL DEFAULT '',
    og_image     TEXT NOT NULL DEFAULT '',
    created_at   INTEGER NOT NULL,
    UNIQUE (affiliate_id, offer_id, placement, campaign)
);

CREATE TABLE IF NOT EXISTS postback_events (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    tid        TEXT NOT NULL,
    event      TEXT NOT NULL DEFAULT '',
    txn_id     TEXT NOT NULL,
    amount     TEXT NOT NULL DEFAULT '',
    currency   TEXT NOT NULL DEFAULT '',
    status     TEXT NOT NULL DEFAULT 'new',   -- new | sending | sent | failed
    attempts   INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL,
    UNIQUE (tid, event, txn_id)
);

CREATE TABLE IF NOT EXISTS reset_tokens (
    token_hash TEXT PRIMARY KEY,
    email      TEXT NOT NULL,
    expires_at INTEGER NOT NULL,
    used       INTEGER NOT NULL DEFAULT 0
);
"""


class Database:
    def __init__(self, path: str):
        if path != ":memory:":
            os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        self._conn = sqlite3.connect(path, check_same_thread=False, isolation_level=None)
        self._conn.row_factory = sqlite3.Row
        self._lock = threading.Lock()
        with self._lock:
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.executescript(SCHEMA)

    def execute(self, sql: str, params: tuple = ()) -> sqlite3.Cursor:
        with self._lock:
            return self._conn.execute(sql, params)

    def one(self, sql: str, params: tuple = ()):
        with self._lock:
            return self._conn.execute(sql, params).fetchone()

    def all(self, sql: str, params: tuple = ()):
        with self._lock:
            return self._conn.execute(sql, params).fetchall()

    # --- partners ---
    def upsert_partner(self, affiliate_id: str, email: str, first_name="", last_name="", phone="") -> None:
        self.execute(
            """INSERT INTO partners (affiliate_id, email, first_name, last_name, phone, created_at)
               VALUES (?, ?, ?, ?, ?, ?)
               ON CONFLICT(affiliate_id) DO UPDATE SET
                 email = excluded.email,
                 first_name = CASE WHEN excluded.first_name != '' THEN excluded.first_name ELSE first_name END,
                 last_name  = CASE WHEN excluded.last_name  != '' THEN excluded.last_name  ELSE last_name  END,
                 phone      = CASE WHEN excluded.phone      != '' THEN excluded.phone      ELSE phone      END""",
            (affiliate_id, email.lower(), first_name, last_name, phone, int(time.time())),
        )

    def partner_by_id(self, affiliate_id: str):
        return self.one("SELECT * FROM partners WHERE affiliate_id = ?", (affiliate_id,))

    def partner_by_email(self, email: str):
        return self.one("SELECT * FROM partners WHERE email = ?", (email.lower(),))
