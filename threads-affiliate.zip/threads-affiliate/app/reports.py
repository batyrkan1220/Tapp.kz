"""Диапазоны дат и агрегация построчного отчёта Offer18 (Reports API)."""
from __future__ import annotations

from collections import defaultdict
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo

# Поля из документации Reports API (параметр fields)
REPORT_FIELDS = (
    "date,offer,offer_name,affiliate,clicks,conversion,impressions,"
    "affiliate_price,currency,status,aff_sub1,aff_sub2"
)

RANGES = ("today", "yesterday", "7d", "month")


def date_range(period: str, tz_name: str, now: datetime | None = None) -> tuple[date, date, float]:
    """Возвращает (с, по, смещение часового пояса в часах для параметра timezone)."""
    tz = ZoneInfo(tz_name)
    now = now.astimezone(tz) if now else datetime.now(tz)
    today = now.date()
    if period == "today":
        start = end = today
    elif period == "yesterday":
        start = end = today - timedelta(days=1)
    elif period == "7d":
        start, end = today - timedelta(days=6), today
    elif period == "month":
        start, end = today.replace(day=1), today
    else:
        raise ValueError(period)
    offset = (now.utcoffset() or timedelta(0)).total_seconds() / 3600
    return start, end, offset


def _norm(row: dict) -> dict:
    """Ключи отчёта приходят как Affiliate_Price / Aff_Sub_1 — приводим к нижнему регистру без '_'."""
    return {k.lower().replace("_", ""): v for k, v in row.items()}


def _num(v) -> float:
    try:
        return float(v)
    except (TypeError, ValueError):
        return 0.0


def aggregate(rows: list[dict], affiliate_id: str) -> dict:
    clicks = conversions = impressions = 0
    earnings: dict[str, dict[str, float]] = defaultdict(lambda: {"approved": 0.0, "pending": 0.0})
    daily: dict[str, dict[str, int]] = defaultdict(lambda: {"clicks": 0, "conversions": 0})
    by_placement: dict[str, dict[str, int]] = defaultdict(lambda: {"clicks": 0, "conversions": 0})
    by_offer: dict[str, dict] = {}

    for raw in rows:
        r = _norm(raw)
        # Страховка: даже если фильтр affiliate проигнорирован, чужие строки не учитываем
        row_aff = str(r.get("affiliate", "")).strip()
        if row_aff and row_aff.lstrip("0") != str(affiliate_id).lstrip("0"):
            continue
        c, cv, imp = int(_num(r.get("clicks"))), int(_num(r.get("conversions"))), int(_num(r.get("impressions")))
        clicks += c
        conversions += cv
        impressions += imp

        day = str(r.get("date") or "")[:10]
        if day:
            daily[day]["clicks"] += c
            daily[day]["conversions"] += cv
        placement = str(r.get("affsub1") or "").strip() or "—"
        by_placement[placement]["clicks"] += c
        by_placement[placement]["conversions"] += cv
        offer_key = str(r.get("offerid") or r.get("offer") or "")
        if offer_key:
            o = by_offer.setdefault(offer_key, {"offer_id": offer_key, "title": "", "clicks": 0, "conversions": 0})
            o["title"] = o["title"] or str(r.get("offername") or "")
            o["clicks"] += c
            o["conversions"] += cv

        if cv > 0:
            status = str(r.get("status") or "").lower()
            currency = str(r.get("currency") or "")
            price = _num(r.get("affiliateprice"))
            if status == "approved":
                earnings[currency]["approved"] += price
            elif status == "pending":
                earnings[currency]["pending"] += price
            # rejected / ended в заработок не входят

    cr = round(conversions / clicks * 100, 2) if clicks else 0.0
    return {
        "totals": {"clicks": clicks, "impressions": impressions, "conversions": conversions, "cr": cr},
        "earnings": {cur: {k: round(v, 2) for k, v in vals.items()} for cur, vals in earnings.items()},
        "daily": [{"date": d, **v} for d, v in sorted(daily.items())],
        "by_placement": sorted(
            ({"placement": k, **v} for k, v in by_placement.items()), key=lambda x: -x["clicks"]
        ),
        "by_offer": sorted(by_offer.values(), key=lambda x: -x["clicks"]),
    }
