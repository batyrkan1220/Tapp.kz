"""Нормализация каталога офферов: только одобренные партнёру, только безопасные поля."""
from __future__ import annotations

import html
import re
from urllib.parse import urlencode

from .config import Settings

PLACEMENTS = ("bio", "post", "comment", "reply")
_TAG = re.compile(r"<[^>]+>")


def _same_id(a, b) -> bool:
    """Ключи вида '00001' и '1' считаем одним ID."""
    try:
        return int(str(a)) == int(str(b))
    except ValueError:
        return str(a) == str(b)


def clean_text(value, limit: int = 600) -> str:
    text = html.unescape(_TAG.sub(" ", str(value or "")))
    text = re.sub(r"\s+", " ", text).strip()
    return text[: limit - 1] + "…" if len(text) > limit else text


def _to_float(v, default=0.0) -> float:
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def pick_payout(offer: dict, affiliate_id: str) -> tuple[float, str, str]:
    """(сумма, валюта, модель). Приоритет: правило именно для партнёра → общее правило → поля оффера."""
    rules = offer.get("payout") or []
    personal = general = None
    for rule in rules:
        groups = rule.get("condition") or []
        flat = [c for g in groups for c in (g if isinstance(g, list) else [g])]
        if not flat:
            general = general or rule
            continue
        fields = {c.get("field") for c in flat}
        if fields == {"affiliate_id"} and any(
            c.get("operator_type") == "is_equal" and _same_id(c.get("value"), affiliate_id) for c in flat
        ):
            personal = rule
    rule = personal or general
    if rule:
        return (
            _to_float(rule.get("affiliate_price")),
            str(rule.get("currency") or offer.get("currency") or ""),
            str(rule.get("affiliate_model") or offer.get("model_affiliate") or ""),
        )
    return (
        _to_float(offer.get("price_affiliate")),
        str(offer.get("currency") or ""),
        str(offer.get("model_affiliate") or ""),
    )


def _affiliate_entry(offer: dict, affiliate_id: str) -> dict | None:
    for key, entry in (offer.get("affiliates") or {}).items():
        if _same_id(key, affiliate_id):
            return entry if isinstance(entry, dict) else {}
    return None


def build_tracking_url(
    settings: Settings, offer_id: str, affiliate_id: str, placement: str | None = None, campaign: str | None = None
) -> str:
    q = [("o", offer_id), ("m", settings.mid), ("a", affiliate_id), ("source", "threads")]
    if placement:
        q.append(("aff_sub1", placement))
    if campaign:
        q.append(("aff_sub2", campaign))
    return f"https://{settings.tracking_domain}/c?{urlencode(q)}"


def normalize_offers(raw: dict, affiliate_id: str, settings: Settings) -> list[dict]:
    data = raw.get("data") or {}
    items = data.values() if isinstance(data, dict) else data
    out = []
    for offer in items:
        if not isinstance(offer, dict):
            continue
        entry = _affiliate_entry(offer, affiliate_id)
        # Оффер виден только если партнёр по нему одобрен
        if entry is None or str(entry.get("status", "")).lower() != "approved":
            continue
        offer_id = str(offer.get("offerid") or offer.get("offer_id") or "")
        if not offer_id:
            continue
        payout, currency, model = pick_payout(offer, affiliate_id)
        creatives = [c.get("url") for c in (offer.get("creatives") or []) if isinstance(c, dict) and c.get("url")]
        # Белый список полей: цены рекламодателя, offer_url, advertiser_id наружу не уходят
        out.append(
            {
                "offer_id": offer_id,
                "title": str(offer.get("offer_name") or f"Оффер {offer_id}"),
                "logo_url": str(offer.get("logo") or ""),
                "image_url": creatives[0] if creatives else "",
                "model": model,
                "payout": payout,
                "currency": currency,
                "description": clean_text(offer.get("offer_description")),
                "countries": str(offer.get("country_allow") or ""),
                "default_tracking_url": build_tracking_url(settings, offer_id, affiliate_id, None, None),
            }
        )
    out.sort(key=lambda o: o["title"].lower())
    return out
