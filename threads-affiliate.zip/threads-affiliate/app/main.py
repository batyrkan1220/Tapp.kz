"""Шлюз партнёрского дашборда: FastAPI-приложение (фабрика create_app для тестов)."""
from __future__ import annotations

import hashlib
import html
import io
import re
import secrets
import sqlite3
import time
from pathlib import Path
from typing import Callable, Literal

import qrcode
import qrcode.image.svg
from fastapi import Depends, FastAPI, Header, HTTPException, Query, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import mailer as mailer_mod
from .config import Settings
from .db import Database
from .offer18 import Offer18Client, Offer18Error
from .offers import PLACEMENTS, build_tracking_url, clean_text, normalize_offers
from .reports import RANGES, REPORT_FIELDS, aggregate, date_range
from .security import (
    Partner,
    RateLimiter,
    TTLCache,
    create_token,
    decode_token,
    verify_postback,
)

STATIC_DIR = Path(__file__).parent / "static"
EMAIL_RE = r"^[^@\s]{1,64}@[^@\s]+\.[^@\s]{2,}$"
# Только краулеры. Слов вроде "Threads" здесь нет намеренно: встроенный браузер
# Threads/Instagram не должен считаться ботом, иначе человек не дойдёт до оффера.
BOT_RE = re.compile(
    r"facebookexternalhit|facebot|meta-externalagent|meta-externalfetcher|meta-webindexer|"
    r"twitterbot|telegrambot|whatsapp|linkedinbot|slackbot|discordbot",
    re.I,
)
REPORT_PAGE_SIZE = 1000


# ------------------------------------------------------------------ модели запросов
class RegisterIn(BaseModel):
    first_name: str = Field(min_length=1, max_length=60)
    last_name: str = Field(min_length=1, max_length=60)
    phone: str = Field(pattern=r"^\+?[0-9\s\-()]{7,20}$")
    email: str = Field(pattern=EMAIL_RE, max_length=254)
    password: str = Field(min_length=8, max_length=128)


class LoginIn(BaseModel):
    email: str = Field(pattern=EMAIL_RE, max_length=254)
    password: str = Field(min_length=1, max_length=128)


class ResetRequestIn(BaseModel):
    email: str = Field(pattern=EMAIL_RE, max_length=254)


class ResetConfirmIn(BaseModel):
    token: str = Field(min_length=20, max_length=200)


class LinkIn(BaseModel):
    offer_id: str = Field(pattern=r"^[\w-]{1,32}$")
    placement: Literal["bio", "post", "comment", "reply"]
    campaign_tag: str = Field(default="", pattern=r"^[A-Za-z0-9_-]{0,32}$")


class PostbackIn(BaseModel):
    tid: str = Field(pattern=r"^[\w\-.:]{6,128}$")
    event: str = Field(default="", pattern=r"^[\w\-.]{0,64}$")
    txn_id: str = Field(pattern=r"^[\w\-.:]{1,128}$")
    amount: str = Field(default="", pattern=r"^(\d{1,12}(\.\d{1,4})?)?$")
    currency: str = Field(default="", pattern=r"^([A-Za-z]{3})?$")
    ts: str = Field(pattern=r"^\d{9,12}$")
    sig: str = Field(min_length=64, max_length=64)


# ------------------------------------------------------------------ вспомогательное
def _http_from_offer18(exc: Offer18Error) -> HTTPException:
    if exc.kind == "invalid_credentials":
        return HTTPException(401, "Неверный email или пароль.")
    if exc.kind == "exists":
        return HTTPException(409, "Партнёр с таким email уже зарегистрирован. Попробуйте войти.")
    if exc.kind == "rejected":
        return HTTPException(400, "Не удалось выполнить операцию. Проверьте введённые данные.")
    return HTTPException(502, "Сервис временно недоступен. Повторите попытку чуть позже.")


def _page(title: str, text: str, status: int = 200) -> HTMLResponse:
    body = (
        '<!doctype html><html lang="ru"><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width,initial-scale=1">'
        f"<title>{html.escape(title)}</title>"
        '<body style="font-family:system-ui,sans-serif;max-width:32rem;margin:3rem auto;padding:0 1rem">'
        f"<h1>{html.escape(title)}</h1><p>{html.escape(text)}</p></body></html>"
    )
    return HTMLResponse(body, status_code=status, headers={"X-Robots-Tag": "noindex"})


def create_app(
    settings: Settings | None = None,
    o18: Offer18Client | None = None,
    send_mail: Callable | None = None,
) -> FastAPI:
    settings = settings or Settings.from_env()
    settings.validate()
    db = Database(settings.db_path)
    o18 = o18 or Offer18Client(settings)
    send_mail = send_mail or mailer_mod.send_mail
    cache = TTLCache()
    limiter = RateLimiter()

    app = FastAPI(
        title="Партнёрский дашборд Threads",
        docs_url="/docs" if settings.dev_mode else None,
        redoc_url=None,
        openapi_url="/openapi.json" if settings.dev_mode else None,
    )
    app.state.settings, app.state.db, app.state.cache, app.state.limiter = settings, db, cache, limiter

    # -------------------------------------------------------------- ошибки
    @app.exception_handler(HTTPException)
    async def _http_exc(_: Request, exc: HTTPException):
        return JSONResponse({"success": False, "error": exc.detail}, status_code=exc.status_code)

    @app.exception_handler(RequestValidationError)
    async def _validation_exc(_: Request, exc: RequestValidationError):
        fields = sorted({str(e["loc"][-1]) for e in exc.errors() if e.get("loc")})
        return JSONResponse(
            {"success": False, "error": "Проверьте введённые данные.", "fields": fields}, status_code=422
        )

    @app.middleware("http")
    async def _headers(request: Request, call_next):
        response = await call_next(request)
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("Referrer-Policy", "same-origin")
        if request.url.path.startswith("/api/"):
            response.headers["Cache-Control"] = "no-store"
        return response

    # -------------------------------------------------------------- зависимости
    def client_ip(request: Request) -> str:
        if settings.trust_proxy:
            fwd = request.headers.get("x-forwarded-for", "")
            if fwd:
                return fwd.split(",")[0].strip()
        return request.client.host if request.client else "0.0.0.0"

    def current_partner(authorization: str = Header(default="")) -> Partner:
        scheme, _, token = authorization.partition(" ")
        if scheme.lower() != "bearer" or not token:
            raise HTTPException(401, "Требуется вход.")
        return decode_token(settings, token)

    def short_url(code: str) -> str:
        return f"{settings.public_base_url}/t/{code}"

    async def partner_offers(affiliate_id: str) -> list[dict]:
        try:
            raw = await cache.get_or_load("offers", settings.offers_ttl, o18.list_offers)
        except Offer18Error as exc:
            raise _http_from_offer18(exc)
        return normalize_offers(raw, affiliate_id, settings)

    # -------------------------------------------------------------- аутентификация
    @app.post("/api/v1/auth/register")
    async def register(body: RegisterIn, request: Request):
        ip = client_ip(request)
        limiter.check(f"reg:ip:{ip}", 5, 3600)
        email = body.email.lower()
        try:
            affiliate_id = await o18.create_affiliate(
                first_name=body.first_name.strip(),
                last_name=body.last_name.strip(),
                email=email,
                password=body.password,
                mobile=re.sub(r"\D", "", body.phone),
                signup_ip=ip,
                status=settings.signup_status,
            )
        except Offer18Error as exc:
            raise _http_from_offer18(exc)
        db.upsert_partner(affiliate_id, email, body.first_name.strip(), body.last_name.strip(), body.phone.strip())

        token, pending = None, False
        try:  # сразу входим; если заявка ещё на модерации, Offer18 вход не подтвердит
            await o18.login(email, body.password)
            token = create_token(settings, affiliate_id, email)
        except Offer18Error as exc:
            pending = exc.kind == "invalid_credentials"
        return {
            "success": True,
            "data": {"affiliate_id": affiliate_id, "token": token, "pending_moderation": pending},
        }

    @app.post("/api/v1/auth/login")
    async def login(body: LoginIn, request: Request):
        email = body.email.lower()
        limiter.check(f"login:ip:{client_ip(request)}", 10, 60)
        limiter.check(f"login:email:{email}", 5, 300)
        try:
            affiliate_id = await o18.login(email, body.password)
        except Offer18Error as exc:
            raise _http_from_offer18(exc)
        db.upsert_partner(affiliate_id, email)
        return {"success": True, "data": {"token": create_token(settings, affiliate_id, email), "affiliate_id": affiliate_id}}

    @app.get("/api/v1/me")
    async def me(p: Partner = Depends(current_partner)):
        row = db.partner_by_id(p.affiliate_id)
        name = f"{row['first_name']} {row['last_name']}".strip() if row else ""
        return {"success": True, "data": {"affiliate_id": p.affiliate_id, "email": p.email, "name": name}}

    @app.post("/api/v1/auth/password-reset")
    async def password_reset(body: ResetRequestIn, request: Request):
        """Шаг 1. Всегда отвечаем одинаково, чтобы нельзя было узнать, есть ли email в системе."""
        email = body.email.lower()
        limiter.check(f"reset:ip:{client_ip(request)}", 5, 3600)
        limiter.check(f"reset:email:{email}", 3, 3600)
        generic = {"success": True, "message": "Если такой email зарегистрирован, мы отправили на него письмо со ссылкой."}
        if not db.partner_by_email(email):
            return generic
        token = secrets.token_urlsafe(32)
        db.execute(
            "INSERT INTO reset_tokens (token_hash, email, expires_at) VALUES (?, ?, ?)",
            (hashlib.sha256(token.encode()).hexdigest(), email, int(time.time()) + 1800),
        )
        link = f"{settings.public_base_url}/#/reset?token={token}"
        try:
            await send_mail(
                settings, email, "Сброс пароля",
                f"Чтобы получить новый пароль, перейдите по ссылке (действует 30 минут):\n{link}\n\n"
                "Если вы не запрашивали сброс, просто проигнорируйте это письмо.",
            )
        except mailer_mod.MailUnavailable:
            raise HTTPException(503, "Сброс пароля временно недоступен. Обратитесь в поддержку.")
        return generic

    @app.post("/api/v1/auth/password-reset/confirm")
    async def password_reset_confirm(body: ResetConfirmIn, request: Request):
        """Шаг 2. Offer18 возвращает новый пароль в ответе — мы отправляем его ТОЛЬКО на почту партнёра."""
        limiter.check(f"resetc:ip:{client_ip(request)}", 10, 3600)
        h = hashlib.sha256(body.token.encode()).hexdigest()
        row = db.one("SELECT * FROM reset_tokens WHERE token_hash = ?", (h,))
        if not row or row["used"] or row["expires_at"] < time.time():
            raise HTTPException(400, "Ссылка недействительна или устарела. Запросите сброс заново.")
        claimed = db.execute("UPDATE reset_tokens SET used = 1 WHERE token_hash = ? AND used = 0", (h,))
        if claimed.rowcount == 0:
            raise HTTPException(400, "Ссылка уже использована.")
        try:
            _, new_password = await o18.reset_password(row["email"])
        except Offer18Error as exc:
            db.execute("UPDATE reset_tokens SET used = 0 WHERE token_hash = ?", (h,))
            raise _http_from_offer18(exc)
        try:
            await send_mail(
                settings, row["email"], "Ваш новый пароль",
                f"Ваш новый пароль: {new_password}\nВойдите и сохраните его в надёжном месте.",
            )
        except mailer_mod.MailUnavailable:
            raise HTTPException(503, "Не удалось отправить письмо. Обратитесь в поддержку.")
        return {"success": True, "message": "Новый пароль отправлен на ваш email."}

    # -------------------------------------------------------------- офферы и ссылки
    @app.get("/api/v1/offers")
    async def offers(p: Partner = Depends(current_partner)):
        return {"success": True, "data": await partner_offers(p.affiliate_id)}

    @app.post("/api/v1/links/generate")
    async def generate_link(body: LinkIn, p: Partner = Depends(current_partner)):
        limiter.check(f"gen:{p.affiliate_id}", 60, 60)
        offer = next((o for o in await partner_offers(p.affiliate_id) if o["offer_id"] == body.offer_id), None)
        if not offer:
            raise HTTPException(404, "Оффер не найден или недоступен вам.")
        target = build_tracking_url(settings, body.offer_id, p.affiliate_id, body.placement, body.campaign_tag)
        key = (p.affiliate_id, body.offer_id, body.placement, body.campaign_tag)
        row = db.one(
            "SELECT code FROM short_links WHERE affiliate_id=? AND offer_id=? AND placement=? AND campaign=?", key
        )
        if row:
            code = row["code"]
        else:
            image = offer["image_url"] or offer["logo_url"] or settings.default_og_image
            for _ in range(5):
                code = secrets.token_urlsafe(6)
                try:
                    db.execute(
                        """INSERT INTO short_links (code, affiliate_id, offer_id, placement, campaign, target_url,
                                                    og_title, og_desc, og_image, created_at)
                           VALUES (?,?,?,?,?,?,?,?,?,?)""",
                        (code, *key, target, offer["title"], clean_text(offer["description"], 200), image, int(time.time())),
                    )
                    break
                except sqlite3.IntegrityError:
                    again = db.one(
                        "SELECT code FROM short_links WHERE affiliate_id=? AND offer_id=? AND placement=? AND campaign=?", key
                    )
                    if again:  # параллельный запрос уже создал такую ссылку
                        code = again["code"]
                        break
            else:
                raise HTTPException(500, "Не удалось создать ссылку. Повторите попытку.")
        return {
            "success": True,
            "data": {
                "code": code,
                "offer_id": body.offer_id,
                "placement": body.placement,
                "tracking_url": target,
                "short_url": short_url(code),
            },
        }

    @app.get("/api/v1/links")
    async def my_links(p: Partner = Depends(current_partner)):
        rows = db.all(
            "SELECT code, offer_id, placement, campaign, og_title, created_at FROM short_links "
            "WHERE affiliate_id = ? ORDER BY created_at DESC LIMIT 200",
            (p.affiliate_id,),
        )
        return {
            "success": True,
            "data": [
                {
                    "code": r["code"], "offer_id": r["offer_id"], "title": r["og_title"],
                    "placement": r["placement"], "campaign_tag": r["campaign"],
                    "short_url": short_url(r["code"]), "created_at": r["created_at"],
                }
                for r in rows
            ],
        }

    @app.get("/api/v1/links/{code}/qr.svg")
    async def link_qr(code: str, p: Partner = Depends(current_partner)):
        row = db.one("SELECT code FROM short_links WHERE code = ? AND affiliate_id = ?", (code, p.affiliate_id))
        if not row:
            raise HTTPException(404, "Ссылка не найдена.")
        img = qrcode.make(short_url(code), image_factory=qrcode.image.svg.SvgPathImage, box_size=10, border=2)
        buf = io.BytesIO()
        img.save(buf)
        return Response(buf.getvalue(), media_type="image/svg+xml")

    # -------------------------------------------------------------- короткая ссылка / Open Graph
    @app.api_route("/t/{code}", methods=["GET", "HEAD"])
    async def short_redirect(code: str, request: Request):
        row = db.one("SELECT * FROM short_links WHERE code = ?", (code,)) if re.fullmatch(r"[\w-]{4,16}", code) else None
        if not row:
            return _page("Ссылка не найдена", "Возможно, она была удалена или набрана с ошибкой.", 404)
        ua = request.headers.get("user-agent", "")
        if request.method == "HEAD" or BOT_RE.search(ua):
            # Краулеру показываем карточку с теми же данными, что увидит человек на странице оффера.
            # Клик в Offer18 при этом НЕ создаётся.
            image = row["og_image"] or settings.default_og_image
            tags = [
                ("og:type", "website"),
                ("og:title", row["og_title"]),
                ("og:description", row["og_desc"]),
                ("og:url", short_url(code)),
                ("og:locale", "ru_RU"),
            ]
            if image:
                tags.append(("og:image", image))
                if image == settings.default_og_image:
                    tags += [("og:image:width", "1200"), ("og:image:height", "630")]
            meta = "".join(f'<meta property="{k}" content="{html.escape(v, quote=True)}">' for k, v in tags)
            body = (
                '<!doctype html><html lang="ru"><head><meta charset="utf-8">'
                f"<title>{html.escape(row['og_title'])}</title>{meta}"
                '<meta name="twitter:card" content="summary_large_image">'
                '<meta name="robots" content="noindex">'
                f'<link rel="canonical" href="{html.escape(short_url(code), quote=True)}"></head>'
                f"<body><p>{html.escape(row['og_desc'])}</p>"
                f'<p><a href="{html.escape(row["target_url"], quote=True)}">Перейти</a></p></body></html>'
            )
            return HTMLResponse(body, headers={"Cache-Control": "public, max-age=300", "X-Robots-Tag": "noindex"})
        return RedirectResponse(row["target_url"], status_code=302, headers={"Cache-Control": "no-store"})

    # -------------------------------------------------------------- статистика
    async def fetch_rows(affiliate_id: str, start, end, tz_offset: float) -> list[dict]:
        rows: list[dict] = []
        for page in range(20):
            chunk = await o18.report(
                {
                    "date_from": start.isoformat(),
                    "date_end": end.isoformat(),
                    "affiliate": affiliate_id,  # берётся только из JWT
                    "timezone": f"{tz_offset:.1f}",
                    "results": str(REPORT_PAGE_SIZE),
                    "page": str(page),
                    "fields": REPORT_FIELDS,
                }
            )
            rows.extend(chunk)
            if len(chunk) < REPORT_PAGE_SIZE:
                break
        return rows

    @app.get("/api/v1/stats")
    async def stats(period: str = Query("7d", alias="range"), p: Partner = Depends(current_partner)):
        if period not in RANGES:
            raise HTTPException(422, "Неизвестный период.")
        limiter.check(f"stats:{p.affiliate_id}", 30, 60)
        start, end, tz_off = date_range(period, settings.report_tz)
        try:
            rows = await cache.get_or_load(
                f"report:{p.affiliate_id}:{start}:{end}", settings.reports_ttl,
                lambda: fetch_rows(p.affiliate_id, start, end, tz_off),
            )
        except Offer18Error as exc:
            raise _http_from_offer18(exc)
        data = aggregate(rows, p.affiliate_id)
        return {"success": True, "data": {"range": period, "date_from": start.isoformat(), "date_end": end.isoformat(), **data}}

    # -------------------------------------------------------------- постбэк от основного продукта
    @app.post("/api/v1/postback")
    async def postback(body: PostbackIn, request: Request):
        """Принимает подписанное событие от продукта и один раз пересылает его в Offer18."""
        limiter.check(f"pb:ip:{client_ip(request)}", 300, 60)
        verify_postback(settings, body.tid, body.event, body.txn_id, body.amount, body.currency, body.ts, body.sig)
        now = int(time.time())
        db.execute(
            """INSERT OR IGNORE INTO postback_events (tid, event, txn_id, amount, currency, status, created_at, updated_at)
               VALUES (?,?,?,?,?, 'new', ?, ?)""",
            (body.tid, body.event, body.txn_id, body.amount, body.currency, now, now),
        )
        row = db.one("SELECT * FROM postback_events WHERE tid=? AND event=? AND txn_id=?", (body.tid, body.event, body.txn_id))
        if row["status"] == "sent":
            return {"success": True, "duplicate": True}
        claimed = db.execute(
            """UPDATE postback_events SET status='sending', attempts=attempts+1, updated_at=?
               WHERE id=? AND (status IN ('new','failed') OR (status='sending' AND updated_at < ?))""",
            (now, row["id"], now - 120),
        )
        if claimed.rowcount == 0:
            return {"success": True, "duplicate": True, "in_progress": True}
        try:
            await o18.send_postback(tid=row["tid"], event=row["event"], amount=row["amount"], currency=row["currency"])
        except Offer18Error:
            db.execute("UPDATE postback_events SET status='failed', updated_at=? WHERE id=?", (int(time.time()), row["id"]))
            raise HTTPException(502, "Не удалось передать конверсию. Повторите запрос.")
        db.execute("UPDATE postback_events SET status='sent', updated_at=? WHERE id=?", (int(time.time()), row["id"]))
        return {"success": True, "duplicate": False}

    @app.get("/healthz")
    async def healthz():
        return {"ok": True}

    # -------------------------------------------------------------- интерфейс
    app.mount("/assets", StaticFiles(directory=STATIC_DIR), name="assets")

    @app.get("/", include_in_schema=False)
    async def index():
        return FileResponse(STATIC_DIR / "index.html", headers={"Cache-Control": "no-cache"})

    return app


def app_factory() -> FastAPI:
    """Точка входа для uvicorn: uvicorn app.main:app_factory --factory"""
    return create_app()
