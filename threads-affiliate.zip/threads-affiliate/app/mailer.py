"""Отправка писем (сброс пароля). Без SMTP работает только в DEV_MODE: письмо пишется в лог."""
from __future__ import annotations

import asyncio
import logging
import smtplib
from email.message import EmailMessage

from .config import Settings

log = logging.getLogger("mailer")


class MailUnavailable(Exception):
    pass


def _send_sync(s: Settings, to: str, subject: str, body: str) -> None:
    msg = EmailMessage()
    msg["From"] = s.smtp_from or s.smtp_user
    msg["To"] = to
    msg["Subject"] = subject
    msg.set_content(body)
    with smtplib.SMTP(s.smtp_host, s.smtp_port, timeout=15) as smtp:
        smtp.starttls()
        if s.smtp_user:
            smtp.login(s.smtp_user, s.smtp_password)
        smtp.send_message(msg)


async def send_mail(s: Settings, to: str, subject: str, body: str) -> None:
    if not s.smtp_host:
        if s.dev_mode:
            log.warning("[DEV] письмо для %s: %s\n%s", to, subject, body)
            return
        raise MailUnavailable("SMTP не настроен")
    try:
        await asyncio.to_thread(_send_sync, s, to, subject, body)
    except (OSError, smtplib.SMTPException) as exc:
        raise MailUnavailable(type(exc).__name__) from exc
