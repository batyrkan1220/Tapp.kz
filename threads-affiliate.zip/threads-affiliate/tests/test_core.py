import time

import pytest
from fastapi.testclient import TestClient

from app.config import Settings
from app.main import create_app
from app.offer18 import Offer18Error
from app.reports import aggregate, date_range
from app.security import postback_signature

PB_SECRET = "p" * 40


class FakeOffer18:
    """Имитация Offer18: фиксирует вызовы, может «ломаться» по требованию."""

    def __init__(self):
        self.users = {"ok@example.kz": ("secret123", "5678")}
        self.postbacks = []
        self.postback_fail = False
        self.report_rows = []
        self.report_calls = []
        self.offers_calls = 0
        self.new_password = "NewPass-123"

    async def login(self, email, password):
        u = self.users.get(email)
        if not u or u[0] != password:
            raise Offer18Error("invalid_credentials")
        return u[1]

    async def create_affiliate(self, **kw):
        if kw["email"] in self.users:
            raise Offer18Error("exists")
        self.users[kw["email"]] = (kw["password"], "9001")
        self.last_signup = kw
        return "9001"

    async def reset_password(self, email):
        return self.users[email][1], self.new_password

    async def list_offers(self):
        self.offers_calls += 1
        return {
            "response": "200",
            "data": {
                "00011": {
                    "offerid": "00011", "offer_name": "Main SaaS", "logo": "https://x/logo.png",
                    "currency": "KZT", "price_affiliate": "1000", "model_affiliate": "CPA",
                    "price_advertiser": "5000", "offer_url": "https://secret-advertiser.example",
                    "advertiser_id": "777", "offer_description": "<b>Регистрация</b>  в сервисе",
                    "payout": [
                        {"affiliate_price": "1000", "currency": "KZT", "affiliate_model": "CPA", "condition": []},
                        {"affiliate_price": "1500", "currency": "KZT", "affiliate_model": "CPA",
                         "condition": [[{"field": "affiliate_id", "operator_type": "is_equal", "value": "05678"}]]},
                    ],
                    "affiliates": {"05678": {"status": "approved"}, "9001": {"status": "pending"}},
                    "creatives": [{"type": "image", "url": "https://x/banner.png"}],
                },
                "00022": {
                    "offerid": "00022", "offer_name": "Чужой оффер", "price_affiliate": "1",
                    "affiliates": {"4242": {"status": "approved"}},
                },
            },
        }

    async def report(self, params):
        self.report_calls.append(params)
        return self.report_rows

    async def send_postback(self, **kw):
        if self.postback_fail:
            raise Offer18Error("unavailable")
        self.postbacks.append(kw)


@pytest.fixture
def env():
    o18 = FakeOffer18()
    mails = []

    async def fake_mail(settings, to, subject, body):
        mails.append((to, subject, body))

    settings = Settings(
        mid="1234", api_key="k", secret_key="s", tracking_domain="trk.example.kz",
        public_base_url="https://go.example.kz", jwt_secret="j" * 40, postback_secret=PB_SECRET,
        db_path=":memory:", dev_mode=True,
    )
    app = create_app(settings, o18, fake_mail)
    return TestClient(app), o18, mails, settings


def login(client, email="ok@example.kz", password="secret123"):
    r = client.post("/api/v1/auth/login", json={"email": email, "password": password})
    assert r.status_code == 200, r.text
    return {"Authorization": "Bearer " + r.json()["data"]["token"]}


# ---------------------------------------------------------------- вход / регистрация
def test_login_and_wrong_password(env):
    client, *_ = env
    h = login(client)
    assert client.get("/api/v1/me", headers=h).json()["data"]["affiliate_id"] == "5678"
    r = client.post("/api/v1/auth/login", json={"email": "ok@example.kz", "password": "bad"})
    assert r.status_code == 401 and r.json()["success"] is False


def test_requires_token(env):
    client, *_ = env
    assert client.get("/api/v1/offers").status_code == 401
    assert client.get("/api/v1/offers", headers={"Authorization": "Bearer garbage"}).status_code == 401


def test_register_never_returns_password_and_flags_pending(env):
    client, o18, *_ = env
    r = client.post("/api/v1/auth/register", json={
        "first_name": "Айдос", "last_name": "Нурлан", "phone": "+7 701 000 00 00",
        "email": "New@Example.kz", "password": "longpassword1"})
    assert r.status_code == 200, r.text
    data = r.json()["data"]
    assert data["affiliate_id"] == "9001"
    assert "longpassword1" not in r.text
    assert o18.last_signup["email"] == "new@example.kz"
    assert o18.last_signup["mobile"] == "77010000000"
    # логин новичка в имитации успешен -> токен выдан
    assert data["token"]


def test_register_duplicate_and_validation(env):
    client, *_ = env
    base = {"first_name": "A", "last_name": "B", "phone": "+77010000000", "email": "ok@example.kz", "password": "longpassword1"}
    assert client.post("/api/v1/auth/register", json=base).status_code == 409
    bad = client.post("/api/v1/auth/register", json={**base, "password": "short"})
    assert bad.status_code == 422 and "password" in bad.json()["fields"]


def test_login_rate_limit(env):
    client, *_ = env
    codes = [client.post("/api/v1/auth/login", json={"email": "ok@example.kz", "password": "x"}).status_code for _ in range(7)]
    assert codes[:5] == [401] * 5 and codes[5] == 429


# ---------------------------------------------------------------- сброс пароля
def test_password_reset_does_not_leak_password(env):
    client, o18, mails, _ = env
    login(client)  # создаёт запись партнёра
    r = client.post("/api/v1/auth/password-reset", json={"email": "ok@example.kz"})
    assert r.status_code == 200 and o18.new_password not in r.text
    token = mails[0][2].split("token=")[1].split()[0]
    unknown = client.post("/api/v1/auth/password-reset", json={"email": "nobody@example.kz"})
    assert unknown.json() == r.json()  # одинаковый ответ
    c = client.post("/api/v1/auth/password-reset/confirm", json={"token": token})
    assert c.status_code == 200 and o18.new_password not in c.text
    assert o18.new_password in mails[1][2] and mails[1][0] == "ok@example.kz"
    again = client.post("/api/v1/auth/password-reset/confirm", json={"token": token})
    assert again.status_code == 400


# ---------------------------------------------------------------- офферы и ссылки
def test_offers_filtered_and_sanitized(env):
    client, o18, *_ = env
    h = login(client)
    r = client.get("/api/v1/offers", headers=h)
    data = r.json()["data"]
    assert [o["offer_id"] for o in data] == ["00011"]  # чужой и неодобренный скрыты
    o = data[0]
    assert o["payout"] == 1500.0  # персональная ставка партнёра
    assert o["description"] == "Регистрация в сервисе"
    for leak in ("secret-advertiser", "777", "5000"):
        assert leak not in r.text
    client.get("/api/v1/offers", headers=h)
    assert o18.offers_calls == 1  # кэш


def test_link_generation_idempotent_and_idor(env):
    client, o18, *_ = env
    h = login(client)
    body = {"offer_id": "00011", "placement": "bio", "campaign_tag": "oct"}
    a = client.post("/api/v1/links/generate", json=body, headers=h).json()["data"]
    b = client.post("/api/v1/links/generate", json=body, headers=h).json()["data"]
    assert a["code"] == b["code"]
    assert a["tracking_url"] == "https://trk.example.kz/c?o=00011&m=1234&a=5678&source=threads&aff_sub1=bio&aff_sub2=oct"
    assert a["short_url"] == f"https://go.example.kz/t/{a['code']}"
    assert client.post("/api/v1/links/generate", json={**body, "offer_id": "00022"}, headers=h).status_code == 404
    assert client.post("/api/v1/links/generate", json={**body, "placement": "evil"}, headers=h).status_code == 422
    assert client.post("/api/v1/links/generate", json={**body, "campaign_tag": "a&b=c"}, headers=h).status_code == 422
    qr = client.get(f"/api/v1/links/{a['code']}/qr.svg", headers=h)
    assert qr.status_code == 200 and qr.text.lstrip().startswith("<?xml") or "<svg" in qr.text
    # другой партнёр не видит ссылку и QR
    o18.users["other@example.kz"] = ("secret123", "4242")
    other = login(client, "other@example.kz")
    assert client.get(f"/api/v1/links/{a['code']}/qr.svg", headers=other).status_code == 404
    assert client.get("/api/v1/links", headers=other).json()["data"] == []
    assert len(client.get("/api/v1/links", headers=h).json()["data"]) == 1


def test_short_link_bot_gets_card_human_gets_redirect(env):
    client, *_ = env
    h = login(client)
    code = client.post("/api/v1/links/generate", json={"offer_id": "00011", "placement": "post"}, headers=h).json()["data"]["code"]
    bot = client.get(f"/t/{code}", headers={"user-agent": "facebookexternalhit/1.1"}, follow_redirects=False)
    assert bot.status_code == 200 and 'property="og:title" content="Main SaaS"' in bot.text
    assert 'og:image" content="https://x/banner.png"' in bot.text
    meta = client.get(f"/t/{code}", headers={"user-agent": "meta-externalagent/1.1"}, follow_redirects=False)
    assert meta.status_code == 200
    # встроенный браузер Threads — это человек
    ua = "Mozilla/5.0 (iPhone) Barcelona 300.0 Threads"
    human = client.get(f"/t/{code}", headers={"user-agent": ua}, follow_redirects=False)
    assert human.status_code == 302
    assert human.headers["location"].startswith("https://trk.example.kz/c?o=00011&m=1234&a=5678&source=threads&aff_sub1=post")
    assert client.get("/t/nope1234", follow_redirects=False).status_code == 404


# ---------------------------------------------------------------- отчёты
ROWS = [
    {"Date": "2026-10-18", "OfferID": 11, "OfferName": "Main SaaS", "Affiliate": 5678, "Clicks": 1, "Conversions": 0,
     "Aff_Sub_1": "bio", "Status": "Approved", "Affiliate_Price": 0, "Currency": "KZT"},
    {"Date": "2026-10-18", "OfferID": 11, "OfferName": "Main SaaS", "Affiliate": 5678, "Clicks": 1, "Conversions": 1,
     "Aff_Sub_1": "bio", "Status": "Approved", "Affiliate_Price": 1500, "Currency": "KZT"},
    {"Date": "2026-10-17", "OfferID": 11, "Affiliate": 5678, "Clicks": 1, "Conversions": 1,
     "Aff_Sub_1": "post", "Status": "Pending", "Affiliate_Price": 1500, "Currency": "KZT"},
    {"Date": "2026-10-17", "OfferID": 11, "Affiliate": 5678, "Clicks": 1, "Conversions": 1,
     "Status": "Rejected", "Affiliate_Price": 1500, "Currency": "KZT"},
    {"Date": "2026-10-17", "OfferID": 11, "Affiliate": 4242, "Clicks": 1, "Conversions": 1,
     "Status": "Approved", "Affiliate_Price": 999, "Currency": "KZT"},
]


def test_aggregate():
    a = aggregate(ROWS, "5678")
    assert a["totals"] == {"clicks": 4, "impressions": 0, "conversions": 3, "cr": 75.0}
    assert a["earnings"] == {"KZT": {"approved": 1500.0, "pending": 1500.0}}  # rejected и чужой не учтены
    assert a["by_placement"][0]["placement"] == "bio"
    assert [d["date"] for d in a["daily"]] == ["2026-10-17", "2026-10-18"]


def test_stats_endpoint_forces_affiliate_from_token(env):
    client, o18, *_ = env
    o18.report_rows = ROWS
    h = login(client)
    r = client.get("/api/v1/stats?range=7d", headers=h)
    assert r.status_code == 200 and r.json()["data"]["totals"]["clicks"] == 4
    call = o18.report_calls[0]
    assert call["affiliate"] == "5678" and call["timezone"] == "5.0"
    assert client.get("/api/v1/stats?range=forever", headers=h).status_code == 422


def test_date_range_almaty():
    from datetime import datetime, timezone
    now = datetime(2026, 10, 18, 21, 0, tzinfo=timezone.utc)  # в Алматы уже 19-е, 02:00
    s, e, off = date_range("today", "Asia/Almaty", now)
    assert (s.isoformat(), e.isoformat(), off) == ("2026-10-19", "2026-10-19", 5.0)
    s, e, _ = date_range("7d", "Asia/Almaty", now)
    assert s.isoformat() == "2026-10-13"
    s, e, _ = date_range("month", "Asia/Almaty", now)
    assert s.isoformat() == "2026-10-01"


# ---------------------------------------------------------------- постбэк
def pb(settings, **over):
    p = {"tid": "D-0001-abcdef", "event": "purchase", "txn_id": "order-1", "amount": "15000",
         "currency": "KZT", "ts": str(int(time.time()))}
    p.update(over)
    p["sig"] = postback_signature(settings.postback_secret, p["tid"], p["event"], p["txn_id"], p["amount"], p["currency"], p["ts"])
    return p


def test_postback_signature_required(env):
    client, o18, _, s = env
    p = pb(s)
    assert client.post("/api/v1/postback", json={**p, "amount": "99999"}).status_code == 401  # подмена суммы
    assert client.post("/api/v1/postback", json={**p, "sig": "0" * 64}).status_code == 401
    old = pb(s, ts=str(int(time.time()) - 7200))
    assert client.post("/api/v1/postback", json=old).status_code == 401
    assert o18.postbacks == []


def test_postback_forwarded_once(env):
    client, o18, _, s = env
    p = pb(s)
    r1 = client.post("/api/v1/postback", json=p)
    r2 = client.post("/api/v1/postback", json=pb(s))  # повтор той же транзакции
    assert r1.json()["duplicate"] is False and r2.json()["duplicate"] is True
    assert o18.postbacks == [{"tid": "D-0001-abcdef", "event": "purchase", "amount": "15000", "currency": "KZT"}]
    other = client.post("/api/v1/postback", json=pb(s, txn_id="order-2"))
    assert other.json()["duplicate"] is False and len(o18.postbacks) == 2


def test_postback_retry_after_failure(env):
    client, o18, _, s = env
    o18.postback_fail = True
    assert client.post("/api/v1/postback", json=pb(s)).status_code == 502
    o18.postback_fail = False
    r = client.post("/api/v1/postback", json=pb(s))
    assert r.status_code == 200 and r.json()["duplicate"] is False and len(o18.postbacks) == 1


# ---------------------------------------------------------------- прочее
def test_settings_validation_blocks_weak_prod_config():
    with pytest.raises(RuntimeError):
        Settings(mid="1", api_key="k", secret_key="s", tracking_domain="t.kz", jwt_secret="short", postback_secret="x").validate()
    Settings(dev_mode=True).validate()


def test_index_and_health(env):
    client, *_ = env
    assert client.get("/healthz").json() == {"ok": True}
    assert client.get("/").status_code == 200
    assert client.get("/docs").status_code == 200  # dev_mode
