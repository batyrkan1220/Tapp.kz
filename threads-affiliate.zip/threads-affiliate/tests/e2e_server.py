"""Запуск приложения с имитацией Offer18 для ручной и браузерной проверки интерфейса.

    python tests/e2e_server.py          # http://127.0.0.1:8765, вход: ok@example.kz / secret123
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import uvicorn

from app.config import Settings
from app.main import create_app
from tests.test_core import ROWS, FakeOffer18


async def _mail(settings, to, subject, body):
    print(f"[mail] {to}: {subject}\n{body}", flush=True)


def build():
    o18 = FakeOffer18()
    o18.report_rows = ROWS
    settings = Settings(
        mid="1234", api_key="k", secret_key="s", tracking_domain="trk.example.kz",
        public_base_url="http://127.0.0.1:8765", jwt_secret="j" * 40, postback_secret="p" * 40,
        db_path=":memory:", dev_mode=True,
    )
    return create_app(settings, o18, _mail)


if __name__ == "__main__":
    uvicorn.run(build(), host="127.0.0.1", port=8765, log_level="warning")
